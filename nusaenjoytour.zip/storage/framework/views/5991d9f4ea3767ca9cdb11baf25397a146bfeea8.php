test
<?php /**PATH C:\laragon\www\Tour\nusaenjoytour\resources\views/pages/home.blade.php ENDPATH**/ ?>