test
<?php /**PATH C:\laragon\www\Tour\nusaenjoytour\resources\views/user/pages/home.blade.php ENDPATH**/ ?>