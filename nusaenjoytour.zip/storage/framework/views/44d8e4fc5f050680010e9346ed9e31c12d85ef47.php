<div class="col-md-4 item-block animate-box" data-animate-effect="fadeIn">
	<h2 class="tittle-tour-md">Best Seller</h2>
	<div class="border-paket">
		<figure>
			<img src="<?php echo e(asset('images/gallery/paket-tour/halfday-west.jpg')); ?>" alt="Free Website Templates FreeHTML5.co" class="img-responsive">
		</figure>
		<div class="paket-padding text-center">
			<h3>Half Day West Tour</h3>

       </div>
       	<div class="col-md-12 text-center animate-box" data-animate-effect="fadeIn">
			<p><a href="<?php echo e(route('halfdaywest')); ?>" class="btn btn-primary with-arrow btn-recommend">Details <i class="icon-arrow-right"></i></a></p>
		</div>
	</div>
	<div class="border-paket">
		<figure>
			<img src="<?php echo e(asset('images/gallery/paket-tour/halfday-snor.jpg')); ?>" alt="Free Website Templates FreeHTML5.co" class="img-responsive">
		</figure>
		<div class="paket-padding text-center">
			<h3>Half Day Tour & Snorkeling</h3>
       </div>
       	<div class="col-md-12 text-center animate-box" data-animate-effect="fadeIn">
			<p><a href="<?php echo e(route('halfdaysnor')); ?>" class="btn btn-primary with-arrow btn-recommend">Details <i class="icon-arrow-right"></i></a></p>
		</div>
	</div>
	<h4 class="contact-us">Any questions or requests ? contact us</h4>
</div>
<?php /**PATH C:\laragon\www\Tour\nusaenjoytour\resources\views/customer/template/best-seller.blade.php ENDPATH**/ ?>