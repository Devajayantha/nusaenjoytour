<?php $__env->startSection('index'); ?>
<div id="fh5co-page">
	<header id="fh5co-header" role="banner">
		<div class="container">
			<div class="row">
				<div class="header-inner">
					<h1><a href="<?php echo e(route('home')); ?>">Balipenidaview<span>.</span></a></h1>
					<nav role="navigation">
						<ul>
							<li><a href="<?php echo e(route('home')); ?>">Home</a></li>
							<li><a href="<?php echo e(route('package')); ?>">Package</a></li>
							<li><a href="<?php echo e(route('gallery')); ?>">Gallery</a></li>
							<li class="active"><a href="<?php echo e(route('contact')); ?>">Contact</a></li>
							<li class="cta"><a href="<?php echo e(route('booking')); ?>">Booking</a></li>
						</ul>
					</nav>
				</div>
			</div>
		</div>
	</header>

<div class="fh5co-page-title" style="background-image: url('<?php echo e(asset('/images/landscape/photo14.jpg')); ?>');">
	<div class="overlay"></div>
	<div class="container">
		<div class="row">
			<div class="col-md-12 animate-box">
				<h1><span class="colored">Contact</span> Us</h1>
			</div>
		</div>
	</div>
</div>


<div class="fh5co-contact animate-box">
	<div class="container">
		<div class="row">
			<div class="col-md-3">
				<h3>Contact Info.</h3>
				<ul class="contact-info">
					<li><i class="icon-map"></i>Br. Semaya, Nusa Penida, Klungkung, Bali</li>
					<li><i class="icon-phone"></i>+62 878-6625-3928</li>
					<li><i class="icon-envelope"></i><a href="#">info@nusapenidaenjoytour.com</a></li>
					<li><i class="icon-globe"></i><a href="#">www.nusapenidaenjoytour.com</a></li>
				</ul>
			</div>
			<div class="col-md-8 col-md-push-1 col-sm-12 col-sm-push-0 col-xs-12 col-xs-push-0">
				<div class="row">
					<form method="post" action="/contact">
						<?php echo e(csrf_field()); ?>

						<div class="col-md-6">
							<div class="form-group">
								<input class="form-control" placeholder="name" type="text" name="name" >
							<?php if($errors->has('name')): ?>
							<span class="invalid-feedback">
								<strong style="color:red;"><?php echo e($errors->first('name')); ?></strong>
							</span>
							<?php endif; ?>
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<input class="form-control" placeholder="Email" type="text" name="email">
								<?php if($errors->has('email')): ?>
								<span class="invalid-feedback">
									<strong style="color:red;"><?php echo e($errors->first('email')); ?></strong>
								</span>
								<?php endif; ?>
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<textarea name="message" class="form-control" id="" cols="30" rows="7" placeholder="Message" ></textarea>
								<?php if($errors->has('message')): ?>
								<span class="invalid-feedback">
									<strong style="color:red;"><?php echo e($errors->first('message')); ?></strong>
								</span>
								<?php endif; ?>
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<button type="submit" value="submit" class="btn btn-primary">Send</button>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>

<div id="map" class="animate-box" data-animate-effect="fadeIn"></div>
<?php echo $__env->make('customer/template/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('customer.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Tour\nusaenjoytour\resources\views/customer/pages/contact.blade.php ENDPATH**/ ?>