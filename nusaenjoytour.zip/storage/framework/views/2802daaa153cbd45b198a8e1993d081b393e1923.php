
<!DOCTYPE html>
    <html class="no-js">
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Penidaenjoytour &mdash; Tour Service Nusa Penida</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="We Tour Nusa Penida is tour guide service in Nusa Penida. We facilities about tour in many packages when is already provided." />
	<meta name="keywords" content="Nusa Penida, Tour Nusa Penida, Beautiful Nusa Penida, Kelingking, Broken Beach, Bali, Explore Nusa Penida" />
	<meta name="author" content="Nusa Penida Tour" />

	<link rel="shortcut icon" href="<?php echo e(asset('images/logo.jpg')); ?>">
    <link href='https://fonts.googleapis.com/css?family=Varela+Round' rel='stylesheet' type='text/css'>

	<!-- Animate.css -->
	<link rel="stylesheet" href="<?php echo e(asset('css/template/animate.css')); ?>">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="<?php echo e(asset('css/template/icomoon.css')); ?>">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="<?php echo e(asset('css/template/bootstrap.css')); ?>">
	<!-- Flexslider  -->
	<link rel="stylesheet" href="<?php echo e(asset('css/template/flexslider.css')); ?>">
	<!-- Theme style  -->
	<link rel="stylesheet" href="<?php echo e(asset('css/template/style.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/template/style.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
    <?php echo $__env->yieldContent('custom-css'); ?>
	<script src="<?php echo e(asset('js/template/modernizr-2.6.2.min.js')); ?>"></script>

	</head>
	<body>
	    <div>
	        <?php echo $__env->yieldContent('index'); ?>
	    </div>

        <script src="<?php echo e(asset('js/template/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/template/jquery.easing.1.3.js')); ?>"></script>
        <script src="<?php echo e(asset('js/template/bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/template/jquery.waypoints.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/template/jquery.flexslider-min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/template/main.js')); ?>"></script>
        <script src="<?php echo e(asset('js/template/chat.js')); ?>"></script>
	</body>
</html>

<?php /**PATH C:\laragon\www\Tour\nusaenjoytour\resources\views/customer/master.blade.php ENDPATH**/ ?>