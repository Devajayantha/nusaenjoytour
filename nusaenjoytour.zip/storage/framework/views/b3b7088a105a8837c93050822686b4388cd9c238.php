<?php $__env->startSection('index'); ?>
	<div id="fh5co-page">
		<header id="fh5co-header" role="banner">
			<div class="container">
				<div class="row">
					<div class="header-inner">
						<h1><a href="<?php echo e(route('home')); ?>">Penidaenjoytour<span>.</span></a></h1>
						<nav role="navigation">
							<ul>
								<li><a href="<?php echo e(route('home')); ?>">Home</a></li>
								<li class="active"><a href="<?php echo e(route('package')); ?>">Package</a></li>
								<li><a href="<?php echo e(route('gallery')); ?>">Gallery</a></li>
								<li><a href="<?php echo e(route('contact')); ?>">Contact</a></li>
								<li class="cta"><a href="<?php echo e(route('booking')); ?>">Booking</a></li>
							</ul>
						</nav>
					</div>
				</div>
			</div>
		</header>
	<?php echo $__env->make('customer/template/slide', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<div id="best-deal">
		<div class="container">
			<div class="row">
				<div class="col-md-8 col-md-offset-2 text-center fh5co-heading animate-box" data-animate-effect="fadeIn">
					<h2>Packages Tour Nusa Penida</h2>
				</div>
				<div class="col-md-4 item-block animate-box" data-animate-effect="fadeIn">
					<div class="fh5co-property">
						<figure>
							<img src="<?php echo e(asset('images/gallery/paket-tour/halfday-west.jpg')); ?>" alt="Free Website Templates FreeHTML5.co" class="img-responsive">
						</figure>
						<div class="paket-padding text-center">
							<h3>Half Day West Tour</h3>
					    </div>
						<div class="col-md-12 text-center animate-box" data-animate-effect="fadeIn">
							<p><a href="<?php echo e(route('halfdaywest')); ?>" class="btn btn-primary with-arrow btn-recommend">Details <i class="icon-arrow-right"></i></a></p>
						</div>
					</div>
				</div>

				<div class="col-md-4 item-block animate-box" data-animate-effect="fadeIn">

					<div class="fh5co-property">
						<figure>
							<img src="<?php echo e(asset('images/gallery/paket-tour/halfday-east.jpg')); ?>" alt="Free Website Templates FreeHTML5.co" class="img-responsive">
						</figure>
						<div class="paket-padding text-center">
							<h3>Half Day Tour East</h3>
					    </div>
						<div class="col-md-12 text-center animate-box" data-animate-effect="fadeIn">
							<p><a href="<?php echo e(route('halfdayeast')); ?>" class="btn btn-primary with-arrow btn-recommend">Details <i class="icon-arrow-right"></i></a></p>
						</div>
					</div>

				</div>
				<div class="col-md-4 item-block animate-box" data-animate-effect="fadeIn">

					<div class="fh5co-property">
						<figure>
							<img src="<?php echo e(asset('images/gallery/paket-tour/halfday-snor.jpg')); ?>" alt="Free Website Templates FreeHTML5.co" class="img-responsive">
						</figure>
						<div class="paket-padding text-center">
							<h3>Half Day Snorkeling Tour</h3>
					    </div>
						<div class="col-md-12 text-center animate-box" data-animate-effect="fadeIn">
							<p><a href="<?php echo e(route('halfdaysnor')); ?>" class="btn btn-primary with-arrow btn-recommend">Details <i class="icon-arrow-right"></i></a></p>
						</div>
					</div>
				</div>

				<div class="col-md-4 item-block animate-box" data-animate-effect="fadeIn">
					<div class="fh5co-property">
						<figure>
							<img src="<?php echo e(asset('images/gallery/paket-tour/1d1n.jpg')); ?>" alt="Free Website Templates FreeHTML5.co" class="img-responsive">
						</figure>
						<div class="paket-padding text-center">
							<h3>1D1N Tour</h3>
    					</div>
						<div class="col-md-12 text-center animate-box" data-animate-effect="fadeIn">
							<p><a href="<?php echo e(route('onedayonenight')); ?>" class="btn btn-primary with-arrow btn-recommend">Details <i class="icon-arrow-right"></i></a></p>
						</div>
					</div>
				</div>

				<div class="col-md-4 item-block animate-box" data-animate-effect="fadeIn">

					<div class="fh5co-property">
						<figure>
							<img src="<?php echo e(asset('images/gallery/paket-tour/1d1n-snor.jpg')); ?>" alt="Free Website Templates FreeHTML5.co" class="img-responsive">
						</figure>
						<div class="paket-padding text-center">
							<h3>1D1N & Snorkeling Tour</h3>
					    </div>
						<div class="col-md-12 text-center animate-box" data-animate-effect="fadeIn">
							<p><a href="<?php echo e(route('onedayonenightsnor')); ?>" class="btn btn-primary with-arrow btn-recommend">Details <i class="icon-arrow-right"></i></a></p>
						</div>
					</div>
                </div>

				<div class="col-md-4 item-block animate-box" data-animate-effect="fadeIn">
					<div class="fh5co-property">
						<figure>
							<img src="<?php echo e(asset('images/gallery/paket-tour/2d1n.jpg')); ?>" alt="Free Website Templates FreeHTML5.co" class="img-responsive">
						</figure>
						<div class="paket-padding text-center">
							<h3>2D1N Tour </h3>
					    </div>
						<div class="col-md-12 text-center animate-box" data-animate-effect="fadeIn">
							<p><a href="<?php echo e(route('twodayonenight')); ?>" class="btn btn-primary with-arrow btn-recommend">Details <i class="icon-arrow-right"></i></a></p>
						</div>
					</div>
				</div>

				<div class="col-md-4 item-block animate-box" data-animate-effect="fadeIn">
					<div class="fh5co-property">
						<figure>
							<img src="<?php echo e(asset('images/gallery/paket-tour/2d1n-snor.jpg')); ?>" alt="Free Website Templates FreeHTML5.co" class="img-responsive">
						</figure>
						<div class="paket-padding text-center">
							<h3>2D1N & Snorkeling Tour</h3>
    					</div>
						<div class="col-md-12 text-center animate-box" data-animate-effect="fadeIn">
							<p><a href="<?php echo e(route('twodayonenightsnor')); ?>" class="btn btn-primary with-arrow btn-recommend">Details <i class="icon-arrow-right"></i></a></p>
						</div>
					</div>
				</div>

				<div class="col-md-4 item-block animate-box" data-animate-effect="fadeIn">

					<div class="fh5co-property">
						<figure>
							<img src="<?php echo e(asset('images/gallery/paket-tour/3d2n.jpg')); ?>" alt="Free Website Templates FreeHTML5.co" class="img-responsive">
						</figure>
						<div class="paket-padding text-center">
							<h3>3D2N Tour</h3>
    					</div>
						<div class="col-md-12 text-center animate-box" data-animate-effect="fadeIn">
							<p><a href="<?php echo e(route('threedaytwonight')); ?>" class="btn btn-primary with-arrow btn-recommend">Details <i class="icon-arrow-right"></i></a></p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="fh5co-cta" style="background-image: url(images/slide_4.jpg);">
		<div class="overlay"></div>
		<div class="container">
			<div class="col-md-12 text-center animate-box" data-animate-effect="fadeIn">
				<h3>Have Planning to Nusa Penida ?</h3>
				<p><a href="<?php echo e(route('booking')); ?>" class="btn btn-primary btn-outline with-arrow">Lets Book now! <i class="icon-arrow-right"></i></a></p>
			</div>
		</div>
	</div>
	<?php echo $__env->make('customer/template/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('customer.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Tour\nusaenjoytour\resources\views/customer/pages/package.blade.php ENDPATH**/ ?>