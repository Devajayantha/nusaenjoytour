<?php $__env->startSection('index'); ?>
<div id="wrapper">
    <ul class="sidebar navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('dashboard')); ?>">
          <i class="fas fa-fw fa-book"></i>
          <span>Booking</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('dashboard.comment')); ?>">
          <i class="fas fa-fw fa-star"></i>
          <span>Comment</span>
        </a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="<?php echo e(route('dashboard.package')); ?>">
          <i class="fas fa-fw fa-edit"></i>
          <span>Package</span>
        </a>
      </li>
    </ul>
    <div id="content-wrapper">
      <div class="container-fluid">
        <div class="card mb-3">
          <div class="card-header">
            <i class="fas fa-table"></i>
            Data Table Package</div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                  <tr>
                    <th>No</th>
                    <th>Package</th>
                    <th>Detail</th>
                    <th>Pax</th>
                    <th>Harga</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td></td>
                            <td><?php echo e($package->id); ?></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      <footer class="sticky-footer">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright © Nusa Penida Enjoy Tour 2021</span>
          </div>
        </div>
      </footer>

    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Tour\nusaenjoytour\resources\views/admin/pages/package.blade.php ENDPATH**/ ?>