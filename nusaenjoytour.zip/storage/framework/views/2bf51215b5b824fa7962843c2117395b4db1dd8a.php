<?php $__env->startSection('index'); ?>
<div id="fh5co-page">
	<header id="fh5co-header" role="banner">
		<div class="container">
			<div class="row">
				<div class="header-inner">
					<h1><a href="<?php echo e(route('home')); ?>">Penidaenjoytour<span>.</span></a></h1>
					<nav role="navigation">
						<ul>
							<li><a href="<?php echo e(route('home')); ?>">Home</a></li>
							<li><a href="<?php echo e(route('package')); ?>">Package</a></li>
							<li><a href="<?php echo e(route('gallery')); ?>">Gallery</a></li>
							<li><a href="<?php echo e(route('contact')); ?>">Contact</a></li>
							<li class="cta"><a href="<?php echo e(route('booking')); ?>">Booking</a></li>
						</ul>
					</nav>
				</div>
			</div>
		</div>
	</header>

<div class="fh5co-page-title" style="background-image: url('<?php echo e(asset('images/landscape/photo2.jpg')); ?>');">
	<div class="overlay"></div>
	<div class="container">
		<div class="row">
			<div class="col-md-12 animate-box">
				<h1><span class="colored">Booking </span>Now </h1>
			</div>
		</div>
	</div>
</div>
<div id="best-deal">
	<div class="container">
		<div class="row">
			<div class="col-md-8 col-md-offset-2 text-center fh5co-heading animate-box" data-animate-effect="fadeIn">
				<h2>Fill Your Information Below</h2>
			</div>
			<div class="col-md-6 col-md-offset-3 fh5co-heading animate-box">
                <form method="post" action="<?php echo e(route('form-booking')); ?>" id="form">
                    <?php echo e(csrf_field()); ?>

                    <?php if(session('success')): ?>
                        <div class="alert alert-success alert-block">
                            <button type="button" class="close" data-dismiss="alert">×</button>
                            <strong><?php echo e(session('success')); ?></strong>
                        </div>
                    <?php endif; ?>
                    <div class="row form-group">
						<div class="col-md-6">
							<input type="hidden" name="booking_no" value="<?php echo e(rand()); ?>">
						</div>
					</div>
                    <div class="row form-group">
                        <div class="col-md-12">
                            <label for="name">Name</label>
							<input type="text" id="name" class="form-control" name="name" placeholder="Your full name">
							<?php if($errors->has('name')): ?>
							<span class="invalid-feedback">
								<strong style="color:red;"><?php echo e($errors->first('name')); ?></strong>
							</span>
							<?php endif; ?>
                        </div>
                    </div>
                    <div class="row form-group">
                        <div class="col-md-12">
                            <label for="email">Email</label>
							<input type="text" id="email" class="form-control" name="email" placeholder="Your email address">
							<?php if($errors->has('email')): ?>
							<span class="invalid-feedback">
								<strong style="color:red;"><?php echo e($errors->first('email')); ?></strong>
							</span>
							<?php endif; ?>
                        </div>
                    </div>

                    <div class="row form-group">
                        <div class="col-md-12">
                            <label for="subject">No Telepon</label>
							<input type="text" id="telp" name="telp" class="form-control" placeholder="Your number telepon">
							<?php if($errors->has('telepon')): ?>
							<span class="invalid-feedback">
								<strong style="color:red;"><?php echo e($errors->first('telepon')); ?></strong>
							</span>
							<?php endif; ?>
                        </div>
					</div>
                    <div class="row form-group">
						<div class="col-md-12">
                            <label for="address">Address</label>
							<input type="text" id="address" class="form-control" name="address" placeholder="Your address">				<?php if($errors->has('address')): ?>
								<span class="invalid-feedback">
									<strong style="color:red;"><?php echo e($errors->first('address')); ?></strong>
								</span>
							<?php endif; ?>
						</div>
					</div>
                    <div class="row form-group">
						<div class="col-md-12 ">
							<label for="departure">Departure</label>
							<input type="date" id="departure" name="departure" class="form-control">
							<?php if($errors->has('departure')): ?>
								<span class="invalid-feedback">
									<strong style="color:red;"><?php echo e($errors->first('departure')); ?></strong>
								</span>
							<?php endif; ?>
						</div>
					</div>
                    <div class="row form-group">
						<div class="col-md-6 ">
							<label for="exampleFormControlSelect1" id="drop_text" >Package</label>
							<select class="form-control" id="package">
								<option selected>Choose...</option>
								<?php $__currentLoopData = $paket; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								    <option value="<?php echo e($dp->id); ?>"><?php echo e($dp->nama_paket); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						</div>
						<div class="col-md-6 ">
							<label for="name">Person/Pax</label>
							<select class="custom-select form-control" id="pax" name="pax">
							</select>
						</div>
					</div>
                    <div class="row form-group">
						<div class="col-md-12">
						<label for="total">Total</label>
							<input type="hidden" id="total" value="" name="amount" class="form-control" placeholder="Total payment">
							<input type="text" id="total-show" value="" name="total-show" class="form-control" placeholder="Total payment">
							<?php if($errors->has('total')): ?>
							<span class="invalid-feedback">
								<strong style="color:red;"><?php echo e($errors->first('total')); ?></strong>
							</span>
							<?php endif; ?>
						</div>
					</div>
                    <div class="row form-group">
						<div class="col-md-12">
							<label for="message">Message</label>
							<textarea name="message" id="message" cols="30" rows="5" class="form-control" placeholder="Say something about your booking"></textarea>
						</div>
					</div>
                    <div class="form-group">
						<button type="submit" value="submit" class="btn btn-primary">Book Now</button>
                    </div>

                </form>
			</div>

		</div>
	</div>
</div>

<?php echo $__env->make('customer/template/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('customer.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Tour\nusaenjoytour\resources\views/customer/pages/booking.blade.php ENDPATH**/ ?>