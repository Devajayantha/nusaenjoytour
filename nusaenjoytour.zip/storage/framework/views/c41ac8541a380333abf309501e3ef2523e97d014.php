<header id="fh5co-header" role="banner">
	<div class="container">
		<div class="row">
			<div class="header-inner">
				<h1><a href="<?php echo e(route('home')); ?>">Penidaenjoytour<span>.</span></a></h1>
				<nav role="navigation">
					<ul>
						<li><a href="<?php echo e(route('home')); ?>">Home</a></li>
						<li class="active"><a href="<?php echo e(route('package')); ?>">Package</a></li>
						<li><a href="<?php echo e(route('gallery')); ?>">Gallery</a></li>
						<li><a href="<?php echo e(route('contact')); ?>">Contact</a></li>
						<li class="cta"><a href="<?php echo e(route('booking')); ?>">Booking</a></li>
					</ul>
				</nav>
			</div>
		</div>
	</div>
</header>
<?php /**PATH C:\laragon\www\Tour\nusaenjoytour\resources\views/customer/template/header-package.blade.php ENDPATH**/ ?>