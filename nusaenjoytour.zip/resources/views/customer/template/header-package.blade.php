<header id="fh5co-header" role="banner">
	<div class="container">
		<div class="row">
			<div class="header-inner">
				<h1><a href="{{route('home')}}">Penidaenjoytour<span>.</span></a></h1>
				<nav role="navigation">
					<ul>
						<li><a href="{{route('home')}}">Home</a></li>
						<li class="active"><a href="{{route('package')}}">Package</a></li>
						<li><a href="{{route('gallery')}}">Gallery</a></li>
						<li><a href="{{route('contact')}}">Contact</a></li>
						<li class="cta"><a href="{{route('booking')}}">Booking</a></li>
					</ul>
				</nav>
			</div>
		</div>
	</div>
</header>
